﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CircleHandler : MonoBehaviour
{
    private Vector2 dropTarget = Vector2.zero;
    private Vector2 touchPos;

    public int targetX;
    public int targetY;
    public int row;
    public int col;
    public BoardManager board;


    public List<(int, int)> selection;
    public int currentLineColor;

    // Start is called before the first frame update
    void Start()
    {
        board = FindObjectOfType<BoardManager>();
        targetX = (int)transform.position.x;
        targetY = (int)transform.position.y;
        col = targetX;
        row = targetY - 5;
        selection = new List<(int, int)>();
    }

    // Update is called once per frame
    void Update()
    {

    }

    private void OnMouseDown()
    {
        //Debug.Log(col);
        //Debug.Log(row);
        //Debug.Log(board.board[col, row].color);
        HandleSelection(col, row, board.board[col, row].color);
    }

    private void OnMouseDrag()
    {
        Vector2 dragPos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        HandleSelection((int) dragPos.x, (int)dragPos.y + 3, currentLineColor);
    }

    private void OnMouseUp()
    {
        if (selection.Count > 1)
        {
            foreach ((int, int) circle in selection)
            {
                Destroy(board.board[circle.Item1, circle.Item2].circleObject);
            }
        }
        selection.Clear();
    }

    private void HandleSelection(int row, int col, int color)
    {
        string aaa = "";
        foreach((int,int) str in selection)
        {
            aaa = aaa + str.ToString();
            Debug.Log(aaa);
        }

        if (selection.Count == 0)
        {
            //Debug.Log("its empty olol");
            currentLineColor = color;
            selection.Add((row, col));
        }
        else
        {
            if (board.board[row, col].color == currentLineColor && isAdjacent(selection, row, col))
            {
                selection.Add((row, col));
                //Debug.Log(row);
                //Debug.Log(col);
                //Debug.Log(selection);
            }
            else
            {
                //selection.Clear();
            }
        }
    }

    public bool isAdjacent(List<(int, int)> selection, int row, int col)
    {
        if (selection[selection.Count - 1].Item1 == row + 1 && selection[selection.Count - 1].Item2 == col)
        {
            return true;
        }
        else if (selection[selection.Count - 1].Item1 == row - 1 && selection[selection.Count - 1].Item2 == col)
        {
            return true;
        }
        else if (selection[selection.Count - 1].Item1 == row && selection[selection.Count - 1].Item2 == col - 1)
        {
            return true;
        }
        else if (selection[selection.Count - 1].Item1 == row && selection[selection.Count - 1].Item2 == col + 1)
        {
            return true;
        }
        else { return false; }
    }



    public void InitDrop(int dropDistance)
    {
        dropTarget = new Vector2(transform.position.x, transform.position.y - dropDistance);
        StartCoroutine(DropCircle());
    }

    private IEnumerator DropCircle()
    {
        WaitForSeconds frameTime = new WaitForSeconds(0.01f);
        Vector2 startPos = transform.position;
        float lerpPercent = 0;

        while (lerpPercent <= 1)
        {
            transform.position = Vector2.Lerp(startPos, dropTarget, lerpPercent);
            lerpPercent += 0.05f;
            yield return frameTime;
        }

        transform.position = dropTarget;
    }

    /*void OnMouseOver()
    {
        touchPos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        Debug.Log(touchPos);
        if (Input.GetMouseButtonDown(0))
        {
            Debug.Log("HIA THERE");
        }
        Debug.Log("HELLO");
    }*/
}
