﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BoardManager : MonoBehaviour
{
    //TODO
    //Programatically center camera

    public struct Circle
    {
        public int color;
        public GameObject circleObject;
        public CircleHandler CH;
        public int dropDistance;
        public int matchNumber;
    }

    public Circle[,] board = new Circle[8, 8];
    private Circle circleClone = new Circle();

    [SerializeField] private Material cRed;
    [SerializeField] private Material cYellow;
    [SerializeField] private Material cGreen;
    [SerializeField] private Material cBlue;
    [SerializeField] private Material cPurple;

    // Start is called before the first frame update
    void Start()
    {
        InitBoard();
    }

    // Update is called once per frame
    void Update()
    {
        /*if (Input.GetMouseButtonDown(0))
        {
            Debug.Log(Camera.main.ScreenToWorldPoint(Input.mousePosition));
            Debug.Log("HELLO");
        }*/
    }

    private void InitBoard()
    {
        for (int y = 0; y < 8; y++)
        {
            for (int x = 0; x < 8; x++)
            {
                SpawnCircle(x, y, 8);
            }
        }
        SkyfallGems();
    }

    private void SpawnCircle(int x, int y, int drop)
    {
        GameObject circle = (GameObject)Instantiate(Resources.Load("Circle"), new Vector2(x, y + 5), Quaternion.identity);

        if (board[x, y].circleObject != null)
        {
            DestroyObject(board[x, y].circleObject);
        }

        board[x, y] = new Circle
        {
            circleObject = circle,
            dropDistance = drop,
            CH = circle.GetComponent<CircleHandler>(),
            matchNumber = 0
        };

        SetColor(x, y);
    }

    private void SetColor(int x, int y)
    {
        int randomColor = Random.Range(0, 5);

        switch (randomColor)
        {
            case 0: // fire
                board[x, y].circleObject.transform.GetComponent<Renderer>().material = cRed;
                break;
            case 1: // water
                board[x, y].circleObject.transform.GetComponent<Renderer>().material = cBlue;
                break;
            case 2: // wood
                board[x, y].circleObject.transform.GetComponent<Renderer>().material = cGreen;
                break;
            case 3: // light
                board[x, y].circleObject.transform.GetComponent<Renderer>().material = cYellow;
                break;
            case 4: // dark
                board[x, y].circleObject.transform.GetComponent<Renderer>().material = cPurple;
                break;
        }
        board[x, y].color = randomColor;
    }

    private void SkyfallGems()
    {
        for (int y = 0; y < 8; y++)
        {
            for (int x = 0; x < 8; x++)
            {
                if (board[x, y].dropDistance > 0)
                {
                    board[x, y].CH.InitDrop(board[x, y].dropDistance);
                    board[x, y].dropDistance = 0;
                }
            }
        }
    }
}
