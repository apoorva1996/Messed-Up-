﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CircleHandler : MonoBehaviour
{
    private Vector2 dropTarget = Vector2.zero;
    private Vector2 touchPos;

    public int targetX;
    public int targetY;
    public int row;
    public int col;
    public BoardManager board;


    public List<(int, int)> selection;
    public int currentLineColor;

    public int offset;

    // Start is called before the first frame update
    void Start()
    {
        board = FindObjectOfType<BoardManager>();
        targetX = (int)transform.position.x;
        targetY = (int)transform.position.y;
        col = targetX;
        row = targetY - 5;
        //col = Mathf.RoundToInt(transform.position.x);
        //row = Mathf.RoundToInt(transform.position.y)-5;
        selection = new List<(int, int)>();

        offset = 3;
    }

    // Update is called once per frame
    void Update()
    {

    }

    public virtual void OnMouseDown()
    {
        //Debug.Log(col);
        //Debug.Log(row);
        //Debug.Log(board.board[col, row].color);
        HandleSelection(col, row, board.board[col, row].color);
    }

    public virtual void OnMouseDrag()
    {
        Vector2 dragPos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        HandleSelection((int) dragPos.x, (int)dragPos.y + 3, currentLineColor);
    }

    public virtual void OnMouseUp()
    {
        int[] intList = new int[8] { 0, 0, 0, 0, 0, 0, 0, 0 };
        if (selection.Count > 1)
        {
            foreach ((int, int) circle in selection)
            {
                SpriteRenderer renderer = board.backgroundTiles[circle.Item1, circle.Item2].GetComponent<SpriteRenderer>();
                renderer.color = new Color(0, 0, 0);
                Destroy(board.board[circle.Item1, circle.Item2].circleObject);
                intList[circle.Item1]++;
            }
            DropRemainingCircles(selection, intList);
        }
        
        selection.Clear();
     
        //intList.Clear();
    }


    private void DropRemainingCircles(List<(int, int)> selected, int[]intList)
    {

        foreach ((int, int) circle in selected)
        {

            for (int y = circle.Item2 + 1; y < 8; y++)
            {
                if (board.board[circle.Item1, y].circleObject != null)
                {
                    board.board[circle.Item1, y].circleObject.transform.position = new Vector2(circle.Item1, y - offset - intList[circle.Item1]);

                    //board.board[circle.Item1, y - intList[circle.Item1]] = new BoardManager.Circle
                    //{
                    //    //circleObject = circle2
                    //    circleObject = board.board[circle.Item1, y].circleObject
                    //};
                    //board.board[circle.Item1, y - intList[circle.Item1]] = board.board[circle.Item1, y];
                }
                else
                    break;

            }
        }
    }

    public void SwapCircle()
    {
        transform.position = board.tilesPos[col, row];
    }

    private void HandleSelection(int row, int col, int color)
    {
        string aaa = "";
        foreach((int,int) str in selection)
        {
            aaa = aaa + str.ToString();
            //Debug.Log(aaa);
        }

        if (selection.Count == 0)
        {
            //Debug.Log("its empty olol");
            currentLineColor = color;
            selection.Add((row, col));
            SpriteRenderer renderer = board.backgroundTiles[row, col].GetComponent<SpriteRenderer>();
            renderer.color = new Color(255, 255, 255);
        }
        else
        {
            if (board.board[row, col].color == currentLineColor && isAdjacent(selection, row, col))
            {
                selection.Add((row, col));
                SpriteRenderer renderer = board.backgroundTiles[row, col].GetComponent<SpriteRenderer>();
                renderer.color = new Color(255, 255, 255);
                //Debug.Log(row);
                //Debug.Log(col);
                //Debug.Log(selection);
            }
            else
            {
                //selection.Clear();
            }
        }
    }

    public bool isAdjacent(List<(int, int)> selection, int row, int col)
    {
        if (selection[selection.Count - 1].Item1 == row + 1 && selection[selection.Count - 1].Item2 == col)
        {
            return true;
        }
        else if (selection[selection.Count - 1].Item1 == row - 1 && selection[selection.Count - 1].Item2 == col)
        {
            return true;
        }
        else if (selection[selection.Count - 1].Item1 == row && selection[selection.Count - 1].Item2 == col - 1)
        {
            return true;
        }
        else if (selection[selection.Count - 1].Item1 == row && selection[selection.Count - 1].Item2 == col + 1)
        {
            return true;
        }
        else { return false; }
    }



    public void InitDrop(int dropDistance)
    {
        dropTarget = new Vector2(transform.position.x, transform.position.y - dropDistance);
        StartCoroutine(DropCircle());
    }

    private IEnumerator DropCircle()
    {
        WaitForSeconds frameTime = new WaitForSeconds(0.01f);
        Vector2 startPos = transform.position;
        float lerpPercent = 0;

        while (lerpPercent <= 1)
        {
            transform.position = Vector2.Lerp(startPos, dropTarget, lerpPercent);
            lerpPercent += 0.05f;
            yield return frameTime;
        }

        transform.position = dropTarget;
    }

    /*void OnMouseOver()
    {
        touchPos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        Debug.Log(touchPos);
        if (Input.GetMouseButtonDown(0))
        {
            Debug.Log("HIA THERE");
        }
        Debug.Log("HELLO");
    }*/
}
