﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RainBowDotHandler : CircleHandler
{

    // Start is called before the first frame update
    public override void OnMouseDown()
    {
        Vector2 temp = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        Debug.Log(temp.x + ", " + temp.y);
    }
    public override void OnMouseDrag()
    {
        Vector2 dragPosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        //tempPosition = dragPosition;
        transform.position = new Vector2(dragPosition.x, dragPosition.y);

    }
    public override void OnMouseUp()
    {
        //finalTouchPosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        //CalculateAngle();
        //Debug.Log("MouseUP");
        transform.position = board.tilesPos[col, row];
    }
    void OnTriggerEnter2D(Collider2D oDot)
    {
        Debug.Log("Tile Collision: " + oDot.GetComponent<BackgroundTile>().col + ", " + oDot.GetComponent<BackgroundTile>().row);
        //Debug.Log("Drag dot: " +col + ", " +row);
        GameObject otherDot = board.board[oDot.GetComponent<BackgroundTile>().col, oDot.GetComponent<BackgroundTile>().row].circleObject;
        board.board[oDot.GetComponent<BackgroundTile>().col, oDot.GetComponent<BackgroundTile>().row].circleObject = this.gameObject;
        board.board[col, row].circleObject = otherDot;
        otherDot.GetComponent<CircleHandler>().row = row;
        otherDot.GetComponent<CircleHandler>().col = col;
        otherDot.GetComponent<CircleHandler>().SwapCircle();
        row = oDot.GetComponent<BackgroundTile>().row;
        col = oDot.GetComponent<BackgroundTile>().col;
        Debug.Log("Drag position: " + col + ", " + row);

    }
}
