﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class BoardManager : MonoBehaviour
{
    //TODO
    //Programatically center camera

    public int binA;
    public int binB;
    public int binC;
    public int binD;
    public int binE;

    public Text binAText;
    public Text binBText;
    public Text binCText;
    public Text binDText;
    public Text binEText;

    private float totalTime = 120;
    //private float totalTime2 = 0;
    private float intervalTime = 1;

    public Text CountDownText;
    //public Text CountUpText;
    public bool DragRainBowDot;

    public struct Circle
    {
        public int color;
        public GameObject circleObject;
        //public CircleHandler CH;
        public int dropDistance;
        public int matchNumber;
    }
    public GameObject rainBowDot;
    public GameObject tilePreFab;
    public int width;
    public int height;
    public int offset = 5;
    public Circle[,] board;
    public Vector2[,] tilesPos;
    public GameObject[,] backgroundTiles;
    private Circle circleClone = new Circle();
    private int randomX;
    private int randomY;
    public int[] dropDistance;

    [SerializeField] private Material cRed;
    [SerializeField] private Material cYellow;
    [SerializeField] private Material cGreen;
    [SerializeField] private Material cBlue;
    [SerializeField] private Material cPurple;

    // Start is called before the first frame update
    void Start()
    {
        board = new Circle[height, width];
        tilesPos = new Vector2[height, width];
        backgroundTiles = new GameObject[height, width];
        dropDistance = new int[width];
        randomX = Random.Range(0, width);
        randomY = Random.Range(0, height);
        InitBoard();
        binA = 30;
        binB = 30;
        binC = 30;
        binD = 30;
        binE = 30;

        CountDownText.text = string.Format("{0:D2}:{1:D2}", (int)totalTime / 60, (int)totalTime % 60);
        //CountUpText.text = string.Format("{0:D2}:{1:D2}", (int)totalTime2 / 60, (int)totalTime2 % 60);

        DragRainBowDot = false;

    }

    // Update is called once per frame
    void Update()
    {
        /*if (Input.GetMouseButtonDown(0))
        {
            Debug.Log(Camera.main.ScreenToWorldPoint(Input.mousePosition));
            Debug.Log("HELLO");
        }*/
        binAText.text = binA.ToString();
        binBText.text = binB.ToString();
        binCText.text = binC.ToString();
        binDText.text = binD.ToString();
        binEText.text = binE.ToString();
        //count down timer
        if (totalTime > 0 && DragRainBowDot==false)
        {
            intervalTime -= Time.deltaTime;

            if (intervalTime <= 0)
            {
                intervalTime += 1;
                totalTime--;

                CountDownText.text = string.Format("{0:D2}:{1:D2}", (int)totalTime / 60, (int)totalTime % 60);
            }
        }
    }

    private void InitBoard()
    {
        for (int y = 0; y < height; y++)
        {
            for (int x = 0; x < width; x++)
            {   
                
                SpawnCircle(x, y, height);
            }
        }
         SkyfallGems();
    }

    public void SpawnCircle(int x, int y, int drop)
    {
        GameObject circle;

        circle = (GameObject)Instantiate(Resources.Load("Circle"), new Vector2(x, y + offset), Quaternion.identity);
        GameObject backgroundTile = Instantiate(tilePreFab, new Vector2(x, y+offset-drop), Quaternion.identity) as GameObject;
        circle.transform.parent = this.transform;
        circle.name = "C( " + x + ", " + y + " )";
        backgroundTile.transform.parent = this.transform;
        backgroundTile.name = "( " + x + ", " + y + " )";
        
        if (board[x, y].circleObject != null)
        {
            DestroyObject(board[x, y].circleObject);
        }
        backgroundTiles[x, y] = backgroundTile;
        tilesPos[x, y] = new Vector2(x, y + offset - drop);

        Debug.Log(tilesPos[x, y].x + ", " + tilesPos[x, y].y);
        board[x, y] = new Circle
        {
            circleObject = circle,
            dropDistance = drop,
    
            matchNumber = 0
        };

        SetColor(x, y);
    }

    public void SpawnCircle2(int x, int y, int drop)
    {
        GameObject circle;
     
        circle = (GameObject)Instantiate(Resources.Load("Circle"), new Vector2(x, y + offset), Quaternion.identity);      
        circle.transform.parent = this.transform.parent;
        circle.name = "C( " + x + ", " + y + " )";
       
        if (board[x, y].circleObject != null)
        {
            DestroyObject(board[x, y].circleObject);
        }              
        //Debug.Log(tilePos[x, y].x + ", " + tilePos[x, y].y);
        board[x, y] = new Circle
        {
            circleObject = circle,
            dropDistance = drop,
     
            matchNumber = 0
        };

        SetColor(x, y);
    }
    public void CreateRainbowDot(int x, int y)
    {
        GameObject rainbowDot = Instantiate(rainBowDot, new Vector2(x, y-3), Quaternion.identity) as GameObject;
        rainbowDot.transform.parent = this.transform.parent;
        rainbowDot.name = "RC( " + x + ", " + y + " )";
        board[x, y].circleObject = rainbowDot;
        SetColor(x, y);
    }

    private void SetColor(int x, int y)
    {
        int randomColor = Random.Range(0, 5);

        switch (randomColor)
        {
            case 0: // fire
                board[x, y].circleObject.transform.GetComponent<Renderer>().material = cRed;
                break;
            case 1: // water
                board[x, y].circleObject.transform.GetComponent<Renderer>().material = cBlue;
                break;
            case 2: // wood
                board[x, y].circleObject.transform.GetComponent<Renderer>().material = cGreen;
                break;
            case 3: // light
                board[x, y].circleObject.transform.GetComponent<Renderer>().material = cYellow;
                break;
            case 4: // dark
                board[x, y].circleObject.transform.GetComponent<Renderer>().material = cPurple;
                break;
        }
        board[x, y].color = randomColor;
    }

    public void SkyfallGems()
    {
        for (int y = 0; y < height; y++)
        {
            for (int x = 0; x < width; x++)
            {
                if (board[x, y].dropDistance > 0)
                {            
                        board[x, y].circleObject.GetComponent<CircleHandler>().InitDrop(board[x, y].dropDistance);                 
                        board[x, y].dropDistance = 0;
                }
            }
        }
    }
    public bool CheckClosedLoop(List<(int, int, Vector2)> selection, int addCol, int addRow)
    {
        int colComp = 0;
        int rowComp = 0;
        for (int i = 0; i < selection.Count - 1; i++)
        {
            colComp = selection[i].Item1;
            rowComp = selection[i].Item2;
            if (CheckAdjacent(addCol, addRow, colComp, rowComp))
            {
                return true;
            }

        }
        return false;
    }
    public bool CheckAdjacent(int colLast, int rowLast, int colComp, int rowComp)
    {
        if (colLast == colComp + 1 && rowLast == rowComp)
        {
            return true;
        }
        else if (colLast == colComp - 1 && rowLast == rowComp)
        {
            return true;
        }
        else if (colLast == colComp && rowLast == rowComp - 1)
        {
            return true;
        }
        else if (colLast == colComp && rowLast == rowComp + 1)
        {
            return true;
        }

        else { return false; }

    }

    public void DropDots()
    {

        int count = 0;
        for (int col = 0; col < width; col++)
        {

            count = 0;
            for (int row = 0; row < height; row++)
            {
                if (board[col, row].circleObject == null)
                {
                    count++;
                }
                else if (count > 0)
                {

                    board[col, row - count].circleObject = board[col, row].circleObject;
                    board[col, row - count].color = board[col, row].color;

                    if (board[col, row].circleObject.GetComponent<RainBowDotHandler>() == null)
                    {
                        //Debug.Log(board.board[col, row].circleObject.GetComponent<CircleHandler>());
                        board[col, row].circleObject.GetComponent<CircleHandler>().row = row - count;
                        board[col, row].circleObject.GetComponent<CircleHandler>().SwapCircle();
                    }
                    else
                    {
                        Debug.Log("DropTest: " + col + ", " + row);
                        Debug.Log("Count: " + count);
                        board[col, row].circleObject.GetComponent<RainBowDotHandler>().row = row - count;
                        board[col, row].circleObject.GetComponent<RainBowDotHandler>().col = col;
                        Debug.Log(board[col, row].circleObject.GetComponent<RainBowDotHandler>().row);
                        board[col, row].circleObject.GetComponent<RainBowDotHandler>().OnMouseUp();
                    }
                    board[col, row].circleObject = null;
                    board[col, row].color = 0;
                }
            }
            dropDistance[col] = count;
        }

    }

    public void RefillBoard()
    {
        //Debug.Log(dropDistance);
        for (int x = 0; x < dropDistance.Length; x++)
        {
            int curRow = 0;

            for (int y = 0; y < dropDistance[x]; y++)
            {
                SpawnCircle2(x, height - curRow - 1, height);
                curRow++;
            }

        }
        SkyfallGems();
    }
    /*public void SetBinCountText()
    {
        binAText.text = "Count: " + binA.ToString();
        binBText.text = "Count: " + binB.ToString();
        binCText.text = "Count: " + binC.ToString();
        binDText.text = "Count: " + binD.ToString();
        binEText.text = "Count: " + binE.ToString();
    }*/
}
